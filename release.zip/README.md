# RealWorld

```sh
# 安装依赖
npm install

# 启动开发服务
npm run dev

这个打包之后的运行真的好快啊，棒棒的
```
